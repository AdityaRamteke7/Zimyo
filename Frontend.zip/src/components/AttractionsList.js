import React from "react";
import "./AttractionList.css";

const AttractionsList = () => {
  const attractions = [
    { id: 1, name: "Roller Coaster", waitTime: "30 min" },
    { id: 2, name: "Ferris Wheel", waitTime: "15 min" },
    { id: 3, name: "Haunted House", waitTime: "25 min" },
  ];

  return (
    <div className="attractions-list">
      <h2>Attractions</h2>
      <ul>
        {attractions.map((attraction) => (
          <li key={attraction.id}>
            <h3>{attraction.name}</h3>
            <p>Wait Time: {attraction.waitTime}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AttractionsList;
