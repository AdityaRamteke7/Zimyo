import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchTickets } from "../redux/ticketsSlice";
import "./TicketsList.css";

const TicketsList = () => {
  const dispatch = useDispatch();
  const { tickets, status, error } = useSelector((state) => state.tickets);

  useEffect(() => {
    if (status === "idle") {
      dispatch(fetchTickets());
    }
  }, [status, dispatch]);

  if (status === "loading")
    return <p className="loading-message">Loading tickets...</p>;
  if (status === "failed")
    return <p className="error-message">Error: {error}</p>;

  return (
    <div className="tickets-list-container">
      <h2>Available Tickets</h2>
      <ul className="tickets-list">
        {tickets.map((ticket) => (
          <li key={ticket.id}>
            <span className="ticket-details">{ticket.type}</span>
            <span className="ticket-date">{ticket.date}</span>
            <span className="ticket-price">${ticket.price}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TicketsList;
