import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { createTicket } from "../redux/ticketsSlice";
import "./TicketBookingForm.css";

const TicketBookingForm = () => {
  const [date, setDate] = useState("");
  const [type, setType] = useState("");
  const [price, setPrice] = useState("");
  const dispatch = useDispatch();
  const { status, error } = useSelector((state) => state.tickets);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!date || !type || !price) {
      alert("Please fill in all fields");
      return;
    }

    try {
      await dispatch(createTicket({ date, type, price })).unwrap();
      alert("Ticket booked successfully");
      setDate("");
      setType("");
      setPrice("");
    } catch (err) {
      alert("Failed to book ticket: " + err.message);
    }
  };

  return (
    <div className="ticket-booking-container">
      <h2>Book a Ticket</h2>
      <form className="ticket-booking-form" onSubmit={handleSubmit}>
        <div>
          <label>Date:</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Type:</label>
          <input
            type="text"
            placeholder="Ticket Type"
            value={type}
            onChange={(e) => setType(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Price:</label>
          <input
            type="number"
            placeholder="Price"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />
        </div>
        <button type="submit" disabled={status === "loading"}>
          {status === "loading" ? "Booking..." : "Book Ticket"}
        </button>
      </form>
      {status === "failed" && <p>Error: {error}</p>}
    </div>
  );
};

export default TicketBookingForm;
