import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

// Fetch all tickets
export const fetchTickets = createAsyncThunk(
  "tickets/fetchTickets",
  async () => {
    const response = await axios.get("/api/tickets");
    return response.data;
  }
);


export const createTicket = createAsyncThunk(
  "tickets/createTicket",
  async (ticketData, { getState }) => {
    const { user } = getState().user;
    const token = user?.token;
    const response = await axios.post("/api/tickets", ticketData, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  }
);

const ticketsSlice = createSlice({
  name: "tickets",
  initialState: {
    tickets: [],
    status: "idle",
    error: null,
  },

  extraReducers(builder) {
    builder
      .addCase(fetchTickets.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchTickets.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.tickets = action.payload;
      })
      .addCase(fetchTickets.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(createTicket.fulfilled, (state, action) => {
        state.tickets.push(action.payload);
      });
  },
});

export default ticketsSlice.reducer;
