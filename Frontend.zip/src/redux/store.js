import { configureStore } from "@reduxjs/toolkit";
import ticketsReducer from "./ticketsSlice";
import userReducer from "./userSlice";

export const store = configureStore({
  reducer: {
    tickets: ticketsReducer,
    user: userReducer,
  },
});
