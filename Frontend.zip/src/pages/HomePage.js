import React from "react";
import "./HomePage.css";

const HomePage = () => (
  <div className="container">
    <h1>Welcome to the Amusement Park</h1>
    <ul className="attractions-list">
      <li>
        <h3>Roller Coaster</h3>
        <p>Wait Time: 30 min</p>
      </li>
      <li>
        <h3>Ferris Wheel</h3>
        <p>Wait Time: 15 min</p>
      </li>
    </ul>
  </div>
);

export default HomePage;
