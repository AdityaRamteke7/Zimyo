import React from "react";
import TicketsList from "../components/TicketsList";
import TicketBookingForm from "../components/TicketBookingForm";
import { useSelector } from "react-redux";
import "./TicketsPage.css";

const TicketsPage = () => {
  const { user } = useSelector((state) => state.user);

  return (
    <div className="tickets-page-container">
      <h1>Book Your Tickets</h1>
      {user ? (
        <div className="tickets-content">
          <TicketsList />
          <TicketBookingForm />
        </div>
      ) : (
        <p>Please log in to book tickets.</p>
      )}
    </div>
  );
};

export default TicketsPage;
